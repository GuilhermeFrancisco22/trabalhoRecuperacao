const express = require('express');
const Vendedor = require('./Vendedor');
const Produto = require('../Produtos/Produto');
const Cliente = require('../Clientes/Cliente');
const vendedorAuth = require('../../middlewares/vendedorauth');
const router = express.Router();


router.get('/cadastroVendedor', (req, res) => {
    res.render('Vendedor/cadastroVendedor');
})

router.get('/loginVendedor', (req, res) => {
    res.render('Vendedor/loginVendedor');
})

router.post('/concluirCadastro', (req, res) => {
    const nome = req.body.nome;
    const email = req.body.email;
    const password = req.body.password;

    if (nome, email, password) {
        Vendedor.findOne({
            where: {
                email: email, 
                password: password,
            }
        }).then((vendedores) => {
            if (vendedores) {
                res.send('Usuario Existente')
            } else {
                Vendedor.create({
                    nome: nome,
                    email: email, 
                    password: password
                }).then(() => res.render('Vendedor/loginVendedor'))
                .catch((err) => res.render('/'))
            }
        })
    } else {
        res.redirect('/')
    }
})

router.post('/autenticarVendedor', (req, res) => {
    const nome = req.body.nome;
    const email = req.body.email;
    const password = req.body.password;

    Vendedor.findOne({
        where: {
            nome: nome,
            email: email, 
            password: password
        }
    }).then((usuario) => {
        if (usuario) {
            req.session.user = {
                nome: nome,
                password: password
            }
            res.render('Vendedor/sessaoVendedor')
        } else {
            res.redirect('/');
        }
    })
})

router.get('/cadastrarProduto', vendedorAuth, (req, res) => {
    res.render('Produto/cadastrarProduto');
})

router.post('/newProduto', (req, res) => {
    const nomeProduto = req.body.nomeProduto;
    const precoProduto = parseFloat(req.body.precoProduto).toFixed(2);
    const quantidade = req.body.quantidade;

    if (nomeProduto, precoProduto, quantidade) {
        Produto.findOne({
            where: {
                nomeProduto: nomeProduto,
            }
        }).then((produto) => {
            if (produto) {
                Produto.findAll().then(produtos => {
                    res.render('Produto/produtoList', {produtos: produto})
                })
            } else {
                Produto.create({
                    nomeProduto: nomeProduto,
                    preco: precoProduto,
                    quantidade: quantidade
                }).then(() => Produto.findAll().then((produtos) => {
                    res.render('Produto/produtoList', {produtos: produtos})
                }))
                .catch((error) => console.log('Falha' + error));
            }
        })
    } else {
        res.render('Produto/cadastrarProduto')
    }
})

router.get('/realizarVenda', vendedorAuth,(req, res) => {
    Produto.findAll().then((produtos) => {
        res.render('Vendedor/realizarVenda', {produtos: produtos});
    })
})

router.post('/venda', async (req, res) => {
    const pedido = req.body.produtos; // ID do produto
    const quantidadePedido = parseInt(req.body.quantidade, 10); // Convertendo a quantidade para número inteiro
    const nomeCliente = req.body.nomeCliente;
    const telefoneCliente = req.body.telefoneCliente;

    if (nomeCliente && telefoneCliente) {
        const t = await sequelize.transaction(); // Iniciando uma transação

        try {
            // Verificando se o cliente existe
            let cliente = await Cliente.findOne({
                where: {
                    nomeCliente: nomeCliente,
                    telefone: telefoneCliente
                },
                transaction: t
            });

            if (!cliente) {
                // Criando um novo cliente se não existir
                cliente = await Cliente.create({
                    nomeCliente: nomeCliente,
                    telefone: telefoneCliente,
                    total: 0
                }, { transaction: t });
            }

            // Verificando se o produto existe
            const produto = await Produto.findByPk(pedido, { transaction: t });

            if (!produto) {
                throw new Error('Produto não encontrado.');
            }

            // Verificando se a quantidade no estoque é suficiente
            if (produto.quantidade < quantidadePedido) {
                throw new Error('Quantidade insuficiente em estoque!');
            }

            // Atualizando o estoque do produto
            const novaQuantidade = produto.quantidade - quantidadePedido;
            await Produto.update(
                { quantidade: novaQuantidade },
                { where: { id: produto.id }, transaction: t }
            );

            // Calculando o total da compra
            const precoTotal = produto.preco * quantidadePedido;

            // Atualizando o total do cliente
            cliente.total += precoTotal;
            await Cliente.update(
                { total: cliente.total },
                { where: { id: cliente.id }, transaction: t }
            );

            // Finalizando a transação
            await t.commit();

            console.log("Venda realizada com sucesso!");
            res.render('Cliente/paginaFinal', {
                cliente: cliente,
                produto: produto,
                quantidadeVendida: quantidadePedido,
                precoTotal: precoTotal
            });

        } catch (error) {
            // Fazendo rollback em caso de erro
            await t.rollback();
            console.error("Erro ao realizar a venda:", error.message);
            res.render('Vendedor/realizarVenda', { error: error.message });
        }
    } else {
        // Caso os dados do cliente não sejam fornecidos
        res.render('Vendedor/sessaoVendedor', { error: 'Por favor, forneça os dados do cliente.' });
    }
});



router.post('/atualizarPedido', (req, res) => {
    const id = req.body.id;
    Cliente.findByPk(id)
    .then((cliente) => {
        Produto.findAll()
        .then((produtos) => res.render('Vendedor/atualizarPedido', {cliente: cliente, produtos: produtos}))
    })
})

router.get('/visualizarProdutos', vendedorAuth, (req, res) => {
    Produto.findAll().then((produtos) => {
        res.render('Produto/produtoList', {produtos: produtos});
    })
})

router.get('/finalizarVenda', (req, res) => {
    Cliente.findAll()
    .then((clientes) => {
        res.render('Cliente/paginaFinal', {clientes: clientes});
    })
})

router.post('/receberPagamento', (req, res) => {
    const id = req.body.id

    Cliente.findByPk(id)
    .then((cliente) => {
        Cliente.update({total: 0}, {
            where: {
                id: cliente.id
            }
        }).then(() => {
            res.render('Vendedor/sessaoVendedor');
        })
    })
})


router.post('/atualizarProdutos', (req, res) => {
    const id = req.body.prod;
    Produto.findOne({
        where: {
            id: id
        }
    }).then((produto) => {
        res.render('Produto/atualizarProdutos', {produtos: produto})
    })
})

router.post('/finalizarAtualizacao', (req, res) => {
    const id = req.body.id; 
    const nomeProduto = req.body.nomeProduto;
    const novaQntd = parseInt(req.body.novaQntd);
    let total = 0;

    Produto.findOne({
        where: {
            nomeProduto: nomeProduto
        }
    }).then((produto) => {
        total = produto.quantidade;
        total += novaQntd;
        
        Produto.update({quantidade: total}, {
            where: {
                nomeProduto: nomeProduto,
            }
        }).then(() => {
            Produto.findAll().then((produtos) => {
                res.render('Produto/produtoList', {produtos: produtos});
            })
        })
    })
})

router.get('/logout', (req, res) => {
    req.session.user = undefined
    res.redirect('/');
})

module.exports = router;